import { PIECE_VALUES } from "../core/pieces";


export function detectMaterialGain(features) {
  if (!features?.capturedPiece || !features?.to) return null;

  const value = PIECE_VALUES[features.capturedPiece] || 0;

  const isRecapture =
    features?.previousSan?.includes("x") &&
    features?.previousSan?.slice(-2) === features?.to;
  const materialChange = features?.materialChange ?? 0;

  // ❌ NU e gain dacă e recapture sau schimb egal
  if (isRecapture || Math.abs(materialChange) < 0.5) {
    return null;
  }

  return {
    type: "materialGain",
    targets: [
      {
        piece: features.capturedPiece,
        square: features.to,
        value,
        isDefended: false,
      },
    ],
  };
}
export function detectMaterialLoss(features) {
    console.log("🔥 MATERIAL LOSS RUNNING");
  const hanging = features?.movedPieceHanging;

  if (hanging && (hanging.value ?? 0) >= 3) {
    const piece = hanging.type || hanging.piece;

    return {
      type: "materialLoss",
      piece,
      square: hanging.square,
      reason: hanging.isDefended ? "recapture" : "undefended",
      targets: [
        {
          piece,
          name: hanging.name,
          square: hanging.square,
          value: hanging.value,
          isDefended: hanging.isDefended,
        },
      ],
    };
  }

  const loss = features.materialChange;
  if (!Number.isFinite(loss) || loss >= 0) return null;

  const piece = features.capturedPiece || "p";
  const value = PIECE_VALUES[piece] || 0;

  return {
    type: "materialLoss",
    piece,
    square: features.to,
    targets: features?.to,
    reason: "recapture"
      ? [{ piece, square: features.to, value, isDefended: false }]
      : [],
  };
}