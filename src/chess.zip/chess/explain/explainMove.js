import { Chess } from "chess.js";
import { moveToHuman } from "../utils";
import { buildCoachMessage } from "./messagebuilder";
import { getPieceName } from "../core/pieces";

const SIGNAL_PRIORITY = {
  check: 100,
  castle: 95,
  materialLoss: 94,
  recapture: 92,
  capture: 90,
  mateThreat: 88,
  materialGain: 86,
  pin: 82,
  battery: 80,
  attack: 78,
  enemyPressure: 72,
  ignoredAttack: 68,
  moveToSafety: 65,
  hanging: 10,
};

const EMPTY_TARGET_TYPES = [
  "attack",
  "battery",
  "pin",
  "enemyPressure",
  "ignoredAttack",
];

function isUsableSignal(signal) {
  if (!signal) return false;

  if (
    signal.targets &&
    signal.targets.length === 0 &&
    EMPTY_TARGET_TYPES.includes(signal.type)
  ) {
    return false;
  }

  return true;
}

function chooseFocusSignal(detections = []) {
  return [...detections]
    .filter(isUsableSignal)
    .sort(
      (a, b) =>
        (SIGNAL_PRIORITY[b.type] || 0) -
        (SIGNAL_PRIORITY[a.type] || 0)
    )[0];
}

function getLabelSentence(label) {
  if (label === "Blunder") return "This is a blunder.";
  if (label === "Mistake") return "This is a mistake.";
  if (label === "Inaccuracy")
    return "This move is slightly imprecise.";
  return "This is a natural move.";
}

function getBestMoveIdea(bestMove, fenBefore) {
  if (!bestMove || bestMove === "—") return "";

  try {
    const chess = new Chess(fenBefore);

    const move =
      /^[a-h][1-8][a-h][1-8][qrbn]?$/.test(bestMove)
        ? chess.move({
            from: bestMove.slice(0, 2),
            to: bestMove.slice(2, 4),
            promotion: bestMove[4] || "q",
          })
        : chess.move(bestMove, { sloppy: true });

    if (!move) return "";

    if (move.captured) {
      const captured =
        getPieceName(move.captured) || "piece";
      return `captures the ${captured}`;
    }

    if (chess.in_check()) {
      return "gives check and forces a response";
    }

    if (
      move.flags?.includes("k") ||
      move.flags?.includes("q")
    ) {
      return "brings the king to safety";
    }

    if (move.piece === "p") {
      return "gains space in the center";
    }

    return "improves the position";
  } catch {
    return "improves the position";
  }
}

/* ------------------- MAIN FUNCTION ------------------- */

export function explainMove({
  label,
  san,
  bestMove,
  side,
  fenBefore,
  detections,
  playedEval,
}) {
  const opener = `${
    side === "w" ? "White" : "Black"
  } played ${san}.`;

  const bestHuman =
    bestMove && bestMove !== "—"
      ? moveToHuman(bestMove, fenBefore)
      : "";

  const isMateScore =
    Math.abs(playedEval) > 90000;

  /* ---- forced mate case ---- */
  if (label === "Blunder" && isMateScore) {
    return `${opener} This allows a forced checkmate. ${
      bestHuman ? `${bestHuman} was better.` : ""
    }`.trim();
  }

  const focusSignal = chooseFocusSignal(detections);

  console.log("Move DEBUG", {
    san,
    detections,
    focusSignal,
  });

  const msg = focusSignal
    ? buildCoachMessage(focusSignal)
    : "";

  /* ---- BEST MOVE TEXT ---- */
  const bestText =
    label !== "Good" && bestHuman && bestHuman !== san
      ? ` A better move was ${bestHuman}.`
      : "";

  /* ---------------- CORE FLOW ---------------- */

  if (focusSignal && msg) {
    const SUPPRESS_LABEL_TYPES = [
      "materialLoss",
      "mateThreat",
      "hanging",
      "recapture",
      "capture",
    ];

    const showLabel = !SUPPRESS_LABEL_TYPES.includes(
      focusSignal.type
    );

    const labelText = showLabel
      ? ` ${getLabelSentence(label)}`
      : "";

    return `${opener} ${msg}${labelText}${bestText}`.trim();
  }

  /* ---- fallback explanation ---- */
  if (label !== "Good" && bestHuman) {
    const idea = getBestMoveIdea(
      bestMove,
      fenBefore
    );

    return `${opener} ${getLabelSentence(label)} ${
      bestHuman
        ? `${bestHuman} was better because it ${idea}.`
        : ""
    }`.trim();
  }

  return `${opener} ${getLabelSentence(label)}`;
}